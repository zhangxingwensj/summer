// @flow

import React from 'react';
import Logo from '.';

export default <Logo />;
