// @flow

import React from 'react';
import Drop from './Drop';

export default <Drop onPress={() => console.log('Pressing...')} />;
