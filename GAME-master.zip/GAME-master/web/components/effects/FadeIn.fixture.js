// @flow

import React from 'react';
import FadeIn from './FadeIn';

export default (
  <FadeIn>
    <div>Nice and smooth</div>
  </FadeIn>
);
