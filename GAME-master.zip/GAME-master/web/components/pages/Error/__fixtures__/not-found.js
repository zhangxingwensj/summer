// @flow

import React from 'react';
import Error from '..';

export default <Error statusCode={404} />;
